%%
clear
clc
delete(instrfindall)
s = serial('COM4');
s.BaudRate=14400;
s.Terminator='CR';
fopen(s);
t = 0 ;
x = 0 ;
startSpot = 0;
interv = 1000 ; % considering 1000 samples
step = 0.1 ; % lowering step has a number of cycles and then acquire more data
while ( t <interv )
    input = fread(s,1,'ushort')
    z = fread(s,1,'ushort')
    %z = fscanf(s,'%u')
    %b = -0.20134*input+424;
    b = asin((2080-input)/410)*180/pi
    b = real(b);
    if b<0
        if z > 2070
            b = -180-b;
        end
    end
    if b > 0
        if z > 2070
            b = 180-b;
        end
    end
    x = [ x, b ];
    plot(x) ;
    %fwrite(s,b,'uchar')
      if ((t/step)-500 < 0)
          startSpot = 0;
      else
          startSpot = (t/step)-500;
      end
      axis([ startSpot, (t/step+50), -190 , 180 ]);
      grid
      t = t + step;
      drawnow;
      pause(0.01)
end


